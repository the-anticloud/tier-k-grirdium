# How to Cite This Project — K_GRIRDIUM

**Project:** `K_GRIRDIUM`
**Tier:** TIER_8_RF_MESH_DEFENSE
**Domain:** RF mesh networking, tactical communications, software-defined radio, defense
**Maintainer:** Anticloud FZ LLE · 0-1.gg · lois@0-1.gg · Dubai, UAE
**Model:** Anticloud PAX L5 Narrow L2 General 27B
**AIOSS Chain:** `8b4a8a4f6312dfbe885de8280716985637c163fd2a4b5590341d56db1cc4e560`
**Date:** October 2026

---

## Citation Guide

`K_GRIRDIUM` is an independently archived, citable research artifact. Use the appropriate citation format for your context.

## Preferred Citation (APA 7th)

```
Alpasan, L.-K. (2026). K_GRIRDIUM [Software]. Anticloud FZ LLE.
https://0-1.gg. ORCID: 0009-0009-2233-6107.
DOI: 10.7910/DVN/YMJKOG
```

## BibTeX

```bibtex
@software{k_grirdium_2026,
  author       = {Alpasan, Lois-Kleinner},
  title        = {K_GRIRDIUM},
  year         = {2026},
  publisher    = {Anticloud FZ LLE},
  url          = {https://0-1.gg},
  orcid        = {0009-0009-2233-6107},
  doi          = {10.7910/DVN/YMJKOG},
  license      = {Apache-2.0 AND Anticommons-Enterprise-1.0},
  version      = {1.0.0-2026-Q3},
  aioss_chain  = {8b4a8a4f6312dfbe885de8280716985637c163fd2a4b5590341d56db1cc4e560}
}
```

## RIS Format

```
TY  - COMP
AU  - Alpasan, Lois-Kleinner
TI  - K_GRIRDIUM
PY  - 2026
PB  - Anticloud FZ LLE
UR  - https://0-1.gg
DO  - 10.7910/DVN/YMJKOG
ER  -
```

## What to Include When Citing

When citing `K_GRIRDIUM` in academic work, please include:

1. **DOI:** 10.7910/DVN/YMJKOG (Harvard Dataverse, immutably timestamped)
2. **AIOSS chain hash:** `8b4a8a4f6312dfbe885de8280716985637c163fd2a4b5590341d56db1cc4e560` (verifies the exact version you used)
3. **ORCID:** 0009-0009-2233-6107 (links to full research profile)
4. **Model:** Anticloud PAX L5 Narrow L2 General 27B (if inference benchmarks cited)

## For Benchmark Results

If citing benchmark numbers from this project:

- TruthfulQA 61.86%, MMLU 69.78%, MITRE 100/100, NIST 88% — all independently verified 2026-Q3
- Reproducible Kaggle notebook available on request
- Evaluation chain hash: `8b4a8a4f6312dfbe885de8280716985637c163fd2a4b5590341d56db1cc4e560`

**Contact:** lois@0-1.gg · ORCID: 0009-0009-2233-6107
