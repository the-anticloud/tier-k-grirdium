# Lab Environment — NIST_AI_RMF_Lab_Results

**Project:** K_GRIRDIUM
**Benchmark:** NIST_AI_RMF_Lab_Results
**Run:** 2026-09-30T18:11:11.493145+00:00

## Environment

| Property | Value |
|----------|-------|
| Platform | Windows 10 Pro |
| Python | 3.10+ |
| Isolation | Static analysis on upstream clone |
| Network | No internet access during analysis |
| Seed method | `sha256(project_name)[:8]` + offsets 0/31337/65536 |

---
